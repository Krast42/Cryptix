import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
from cryptography.fernet import Fernet

SECRET_KEY = "aIkXkSHDxf423shYhCOfRBz8I3ekMtEx5h1QkfHlTEg="
cipher = Fernet(SECRET_KEY.encode())

LANGUAGES = {
    "en": {
        "encrypt": "🔒 Encrypt",
        "decrypt": "🔓 Decrypt",
        "clear": "🧹 Clear",
        "input": "Input text",
        "output": "Result",
        "warn_input": "Enter text first.",
        "warn_decrypt": "Invalid key or text.",
        "warn_copy": "No text to copy.",
        "hint": "Hotkeys: Ctrl+V — paste, Ctrl+C — copy",
        "change_key": "Change Key",
        "key_window_title": "Encryption Key",
        "current_key": "Current key:",
        "key_label": "Enter or generate new key:",
        "generate": "Generate",
        "save": "Save",
        "copy": "Copy"
    },
    "ru": {
        "encrypt": "🔒 Зашифровать",
        "decrypt": "🔓 Расшифровать",
        "clear": "🧹 Очистить",
        "input": "Ввод текста",
        "output": "Результат",
        "warn_input": "Введите текст.",
        "warn_decrypt": "Неверный ключ или поврежденный текст.",
        "warn_copy": "Нет текста для копирования.",
        "hint": "Сочетания: Ctrl+V — вставить, Ctrl+C — скопировать",
        "change_key": "Изменить ключ",
        "key_window_title": "Ключ шифрования",
        "current_key": "Текущий ключ:",
        "key_label": "Введите или сгенерируйте новый ключ:",
        "generate": "Сгенерировать",
        "save": "Сохранить",
        "copy": "Копировать"
    },
    "es": {
        "encrypt": "🔒 Encriptar",
        "decrypt": "🔓 Desencriptar",
        "clear": "🧹 Limpiar",
        "input": "Texto de entrada",
        "output": "Resultado",
        "warn_input": "Ingrese texto.",
        "warn_decrypt": "Clave o texto inválido.",
        "warn_copy": "Nada que copiar.",
        "hint": "Atajos: Ctrl+V — pegar, Ctrl+C — copiar",
        "change_key": "Cambiar clave",
        "key_window_title": "Clave de cifrado",
        "current_key": "Clave actual:",
        "key_label": "Ingrese o genere nueva clave:",
        "generate": "Generar",
        "save": "Guardar",
        "copy": "Copiar"
    },
    "fr": {
        "encrypt": "🔒 Chiffrer",
        "decrypt": "🔓 Déchiffrer",
        "clear": "🧹 Effacer",
        "input": "Texte d'entrée",
        "output": "Résultat",
        "warn_input": "Veuillez entrer du texte.",
        "warn_decrypt": "Clé ou texte invalide.",
        "warn_copy": "Aucun texte à copier.",
        "hint": "Raccourcis: Ctrl+V — coller, Ctrl+C — copier",
        "change_key": "Changer la clé",
        "key_window_title": "Clé de chiffrement",
        "current_key": "Clé actuelle:",
        "key_label": "Entrez ou générez une nouvelle clé:",
        "generate": "Générer",
        "save": "Sauvegarder",
        "copy": "Copier"
    },
    "de": {
        "encrypt": "🔒 Verschlüsseln",
        "decrypt": "🔓 Entschlüsseln",
        "clear": "🧹 Löschen",
        "input": "Eingabetext",
        "output": "Ergebnis",
        "warn_input": "Bitte Text eingeben.",
        "warn_decrypt": "Ungültiger Schlüssel oder Text.",
        "warn_copy": "Kein Text zum Kopieren.",
        "hint": "Tastenkürzel: Ctrl+V — einfügen, Ctrl+C — kopieren",
        "change_key": "Schlüssel ändern",
        "key_window_title": "Verschlüsselungsschlüssel",
        "current_key": "Aktueller Schlüssel:",
        "key_label": "Neuen Schlüssel eingeben oder generieren:",
        "generate": "Generieren",
        "save": "Speichern",
        "copy": "Kopieren"
    }
}

current_lang = "en"

def set_lang(event=None):
    global current_lang
    lang = lang_selector.get()
    if lang == "English": current_lang = "en"
    elif lang == "Русский": current_lang = "ru"
    elif lang == "Español": current_lang = "es"
    elif lang == "Français": current_lang = "fr"
    elif lang == "Deutsch": current_lang = "de"
    apply_lang()

def apply_lang():
    t = LANGUAGES[current_lang]
    frame_input.config(text=t["input"])
    frame_output.config(text=t["output"])
    btn_encrypt.config(text=t["encrypt"])
    btn_decrypt.config(text=t["decrypt"])
    btn_clear.config(text=t["clear"])
    btn_change_key.config(text=t["change_key"])
    hint.config(text=t["hint"])

def encrypt_message():
    text = input_text.get("1.0", tk.END).strip()
    if not text:
        messagebox.showwarning("", LANGUAGES[current_lang]["warn_input"])
        return
    encrypted = cipher.encrypt(text.encode()).decode()
    output_text.delete("1.0", tk.END)
    output_text.insert(tk.END, encrypted)

def decrypt_message():
    text = input_text.get("1.0", tk.END).strip()
    if not text:
        messagebox.showwarning("", LANGUAGES[current_lang]["warn_input"])
        return
    try:
        decrypted = cipher.decrypt(text.encode()).decode()
        output_text.delete("1.0", tk.END)
        output_text.insert(tk.END, decrypted)
    except:
        messagebox.showerror("", LANGUAGES[current_lang]["warn_decrypt"])

def clear_fields():
    input_text.delete("1.0", tk.END)
    output_text.delete("1.0", tk.END)

def paste_from_clipboard():
    try:
        text = window.clipboard_get()
    except Exception:
        return "break"
    input_text.delete("1.0", tk.END)
    input_text.insert(tk.END, text)
    return "break"

def copy_to_clipboard():
    text = output_text.get("1.0", tk.END).strip()
    if not text:
        return "break"
    window.clipboard_clear()
    window.clipboard_append(text)
    return "break"

def handle_ctrl(event):
    if event.keycode == 86:  # V
        return paste_from_clipboard()
    if event.keycode == 67:  # C
        return copy_to_clipboard()

def open_key_window():
    t = LANGUAGES[current_lang]
    key_win = tk.Toplevel(window)
    key_win.title(t["key_window_title"])
    key_win.geometry("600x250")
    key_win.config(bg="#2b2b2b")

    tk.Label(key_win, text=t["current_key"], bg="#2b2b2b", fg="white").pack(pady=5)
    frame_key = tk.Frame(key_win, bg="#2b2b2b")
    frame_key.pack(pady=5, fill="x")

    current_key_entry = tk.Entry(frame_key, font=("Consolas", 10))
    current_key_entry.insert(0, SECRET_KEY)
    current_key_entry.config(state="readonly", width=70)
    current_key_entry.pack(side="left", padx=5, expand=True, fill="x")

    def copy_current_key():
        window.clipboard_clear()
        window.clipboard_append(SECRET_KEY)
        window.update()

    copy_btn = tk.Button(frame_key, text="📋", width=3, command=copy_current_key)
    copy_btn.pack(side="left", padx=5)

    tk.Label(key_win, text=t["key_label"], bg="#2b2b2b", fg="white").pack(pady=5)
    key_entry = tk.Entry(key_win, width=70, font=("Consolas", 10))
    key_entry.pack(pady=5, fill="x", padx=10)

    def generate_key():
        new_key = Fernet.generate_key().decode()
        key_entry.delete(0, tk.END)
        key_entry.insert(0, new_key)

    def save_key():
        global SECRET_KEY, cipher
        new_key = key_entry.get().strip()
        try:
            test_cipher = Fernet(new_key.encode())  
            cipher = test_cipher
            SECRET_KEY = new_key
            current_key_entry.config(state="normal")
            current_key_entry.delete(0, tk.END)
            current_key_entry.insert(0, SECRET_KEY)
            current_key_entry.config(state="readonly")
            key_entry.delete(0, tk.END)
            messagebox.showinfo("", LANGUAGES[current_lang]["change_key"] + " OK!")
        except:
            messagebox.showerror("", "❌ " + LANGUAGES[current_lang]["warn_decrypt"])

    btn_frame = tk.Frame(key_win, bg="#2b2b2b")
    btn_frame.pack(pady=10)

    gen_btn = tk.Button(btn_frame, text=t["generate"], command=generate_key, bg="#2196F3", fg="white", width=12)
    gen_btn.grid(row=0, column=0, padx=10)

    save_btn = tk.Button(btn_frame, text=t["save"], command=save_key, bg="#4CAF50", fg="white", width=12)
    save_btn.grid(row=0, column=1, padx=10)

window = tk.Tk()
window.geometry("900x600")   
window.config(bg="#2b2b2b")
window.title("Cryptix")

window.grid_rowconfigure(2, weight=1)
window.grid_rowconfigure(4, weight=1)
window.grid_columnconfigure(0, weight=1)

top_frame = tk.Frame(window, bg="#2b2b2b")
top_frame.grid(row=0, column=0, sticky="ew", pady=5)
top_frame.grid_columnconfigure(0, weight=1)

lang_selector = ttk.Combobox(
    top_frame,
    values=["English", "Русский", "Español", "Français", "Deutsch"],
    state="readonly",
    width=12
)
lang_selector.set("English")
lang_selector.bind("<<ComboboxSelected>>", set_lang)
lang_selector.pack(side="left", padx=10)

btn_change_key = tk.Button(top_frame, bg="#9C27B0", fg="white", width=15, command=open_key_window)
btn_change_key.pack(side="right", padx=10)

title = tk.Label(window, text="Cryptix", font=("Arial", 18, "bold"), bg="#2b2b2b", fg="white")
title.grid(row=1, column=0, pady=5)

frame_input = tk.LabelFrame(window, bg="#2b2b2b", fg="white", font=("Arial", 11, "bold"))
frame_input.grid(row=2, column=0, sticky="nsew", padx=15, pady=5)

input_text = scrolledtext.ScrolledText(frame_input, wrap=tk.WORD, font=("Consolas", 12))
input_text.pack(fill="both", expand=True, padx=5, pady=5)

btn_frame = tk.Frame(window, bg="#2b2b2b")
btn_frame.grid(row=3, column=0, pady=10)

btn_encrypt = tk.Button(btn_frame, bg="#4CAF50", fg="white", width=15, height=2, command=encrypt_message)
btn_encrypt.grid(row=0, column=0, padx=20)

btn_decrypt = tk.Button(btn_frame, bg="#2196F3", fg="white", width=15, height=2, command=decrypt_message)
btn_decrypt.grid(row=0, column=1, padx=20)

btn_clear = tk.Button(btn_frame, bg="#f44336", fg="white", width=15, height=2, command=clear_fields)
btn_clear.grid(row=0, column=2, padx=20)

frame_output = tk.LabelFrame(window, bg="#2b2b2b", fg="white", font=("Arial", 11, "bold"))
frame_output.grid(row=4, column=0, sticky="nsew", padx=15, pady=5)

output_text = scrolledtext.ScrolledText(frame_output, wrap=tk.WORD, font=("Consolas", 12))
output_text.pack(fill="both", expand=True, padx=5, pady=5)

hint = tk.Label(window, font=("Arial", 10), bg="#2b2b2b", fg="gray")
hint.grid(row=5, column=0, pady=5)

window.bind_all("<Control-KeyPress>", handle_ctrl)

apply_lang()
window.mainloop()